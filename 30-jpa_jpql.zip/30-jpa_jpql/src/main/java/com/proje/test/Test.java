package com.proje.test;

import java.util.Date;
import java.util.List;

import com.proje.model.Brand;
import com.proje.model.Category;
import com.proje.model.Product;
import com.proje.model.ProductDetails;
import com.proje.repository.ProductRepository;
import com.proje.repository.Impl.ProductRepositoryImpl;
//import com.proje.repository.ProductRepository;
//import com.proje.repository.Impl.ProductRepositoryImpl;

public class Test {
	private static ProductRepository productRepository = new  ProductRepositoryImpl();
	
	public static void main(String[] args) {
		//insertData();
		
		/*(1) "SELECT p FROM Product p"
		List<Product> products = productRepository.findProduct();
		System.out.println("Merhaba");
		for (Product product : products) {
			System.out.println(product);
		}*/  //veya products.forEach(System.out.println);
		
		/*(2)
		Product product = productRepository.findProductById(5);
		System.out.println(product);
		*/
		
		/*(3)
		List<ProductDetails> productDetails = productRepository.findProductDetails();
		productDetails.forEach(System.out::println);
		*/
		
		/*(4)
		List<String> productNames = productRepository.findProductNames();
		productNames.forEach(System.out::println);
		*/
		
		/*(5)
		// List 'in i�inde ka� tane sat�r varsa  o kadar dizi olu�turuluyor Object 'de
		//2 kolon isteniyor yani her bir dizinin boyutu 2 dir o zaman
		//Yani Objemiz i�ersinde 9 tane dizi mevcut
		List<Object[]> list = productRepository.findProductNameAndPrice();
		for (Object[] objects : list) {
			
			System.out.println(objects[0] + " - "+ objects[1]);
		}
		*/
		
		/*(6)
		List<Product> product = productRepository.findGreatPrice(2700);
		product.forEach(System.out::println);
		*/
		
		/*(7)
		List<Product> product = productRepository.findGreatAndLessPrice(2500, 3200);
		product.forEach(System.out::println);
		*/
		
		/*(8)
		List<Product> product = productRepository.findBetweenPrice(2500, 3200);
		product.forEach(System.out::println);
		*/
		
		/*(9)
		List<Product> product = productRepository.findLikeProductName("sus");
		product.forEach(System.out::println);
		*/
		
		/*(10)
		List<Product> product = productRepository.findInCategoryNme("Telefon", "Bilgisayar");
		product.forEach(System.out::println);
		*/
		
		/*(11)
		List<Product> product = productRepository.findAllProducts(2);
		product.forEach(System.out::println);
		*/
		
		/*(12)
		List<Object[]> list = productRepository.findFunctionPrice();
		Object[] objects = list.get(0); //0. index deki eleman
		System.out.println("AVG : "+objects[0] +"-SUM :" + objects[1]+"MAX : "+objects[2] + "-MIN : " + objects[3] + "COUNT :"+objects[3]);
		*/
		
		/*(13)
		List<Object[]> list = productRepository.findGroupByCategory();
		for (Object[] objects : list) {
			System.out.println("CategoryName : "+objects[0]+"-AVG :" + objects[1]);
		}*/
		
		
		/*(14) Hatal� yada eksik bende
		List<Object[]> list = productRepository.findGroupByHavingCategory(2600);
		for (Object[] objects : list) {
		System.out.println("CategoryName : "+objects[0]+"-AVG :" + objects[1]);
		}*/
		
		/*(15) Hatal� yada eksik bende
		List<Product> product = productRepository.findOderderByPrice();
		product.forEach(System.out::println);
		 */
	}
	
	public static void insertData() {
		//Verilerin eklenece�i metod yazl�m
		
		Brand brand1 = new Brand("APPLE");
		Brand brand2 = new Brand("LG");
		Brand brand3 = new Brand("SONY");
		Brand brand4 = new Brand("SAMSUNG");
		Brand brand5 = new Brand("ASUS");
		
		Category category1 = new Category("Bilgisayar");
		Category category2 = new Category("Tablet");
		Category category3 = new Category("Telefon");
		
	Product product1 = new Product("Iphone 7", 3500, 1, brand1, category3, new Date());
	Product product2 = new Product("LG G5", 2400, 1, brand2, category3, new Date());
	Product product3 = new Product("Sony Ecperia", 2700, 1, brand3, category3, new Date());
	
	Product product4 = new Product("Samsung Z500", 2300, 1, brand4, category1, new Date());
	Product product5 = new Product("Mac OS", 4100, 1, brand1, category1, new Date());
	Product product6 = new Product("ASUS �7", 2400, 2, brand3, category1, new Date());
	
	Product product7 = new Product("Samsung Tablet", 2200, 1, brand4, category2, new Date());
	Product product8 = new Product("IPad", 2600, 3, brand5, category2, new Date());
	Product product9 = new Product("Sony Tablet", 2450, 1, brand3, category2, new Date());
		
	productRepository.saveBrand(brand1);
	productRepository.saveBrand(brand2);
	productRepository.saveBrand(brand3);
	productRepository.saveBrand(brand4);
	productRepository.saveBrand(brand5);
	
	productRepository.saveCategory(category1);
	productRepository.saveCategory(category2);
	productRepository.saveCategory(category3);
	
	productRepository.saveProduct(product1);
	productRepository.saveProduct(product2);
	productRepository.saveProduct(product3);
	productRepository.saveProduct(product4);
	productRepository.saveProduct(product5);
	productRepository.saveProduct(product6);
	productRepository.saveProduct(product7);
	productRepository.saveProduct(product8);
	productRepository.saveProduct(product9);
	
	
	}
	
	
}
