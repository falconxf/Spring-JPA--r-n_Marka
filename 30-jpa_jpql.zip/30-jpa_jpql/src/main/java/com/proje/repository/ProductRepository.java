package com.proje.repository;

import java.util.List;

import com.proje.model.Brand;
import com.proje.model.Category;
import com.proje.model.Product;
import com.proje.model.ProductDetails;


public interface ProductRepository {
	
	Product saveProduct(Product product);		//1 �r�n� veri taban�na kaydetmek i�in
	
	Brand saveBrand(Brand brand); // Marka kaydetmek i�in
	
	Category saveCategory(Category category);//Kategori kaydetmek i�in
	
	List<Product> findProduct(); //B�t�n �r�nleri veri taban�ndan �ekmek i�in
	
	List<Product> findProductEntities(int firstResult , int maxResult); //Veri taban�ndan verileri �ek ama �ekerken verielen aral�ktakileri �ek
	
	Product findProductById(int productId);//id ile arama
	
	List<ProductDetails> findProductDetails(); //
	
	ProductDetails findProductDetailsById(int productId);//
	
	List<String> findProductNames();//Veri taban�ndaki �r�nlerin isimlerii getir
	
	List<Object[]> findProductNameAndPrice();//Hem ad�n� hemde fiyatlar�n� getirecek
	
	List<Product> findGreatPrice(double unitPrice);//
	
	List<Product> findGreatAndLessPrice(double minUnitPrice,double maxUnitPrice);
	
	List<Product> findBetweenPrice(double minUnitPrice,double maxUnitPrice);
	
	List<Product> findLikeProductName(String productName);
	
	List<Product> findInCategoryNme(String categoryName1 , String categoryName2);
	
	List<Product> findAllProducts(int categoryId);
	
	List<Object[]> findFunctionPrice();
	
	List<Object[]> findGroupByCategory();
	
	List<Object[]> findGroupByHavingCategory(double unitPrice);
	
	List<Product> findOderderByPrice(double unitPrice);
}
