package com.proje.queries;

public class ProductQueries {
	/*
	 * SELECT p FROM product p
	 * 
	 */
	
	public static final String findProducts = "SELECT p FROM Product p";
	
	public static final String findProductsById = "SELECT p FROM Product p WHERE p.productId : productId";
	
	public static final String findProductDetails ="SELECT new com.proje.model.ProductDetails(p.productName , p.unitPrice , p.avaible , b.brandName , c.categoryName)" 
													+ "FROM Product p LEFT JOIN p.brand b LEFT JOIN p.category c";
	
	public static final String findProductDetailsById ="SELECT new com.proje.model.ProductDetails(p.productName , p.unitPrice , p.avaible , b.brandName , c.categoryName)" 
			+ "FROM Product p LEFT JOIN p.brand b LEFT JOIN p.category c WHERE p�productId = : productId";
	
	public static final String findProductNames = "SELECT p.productName FROM Product p";
	
	public static final String findProdctNamePrice = "SELECT p.productName , p.unitPrice FROM Product p";
	
	public static final String findGreatPrice = "SELECT p FROM Product p WHERE p.unitPrice >: unitPrice";
	
	public static final String findGreatLessPrice = "SELECT p FROM Product p WHERE p.unitPrice >: minUnitPrice AND p.unitPrice < :maxUnitPrice";
	
	public static final String findBetweenPrice = "SELECT p FROM Product p WHERE p.unitPrice >: minUnitPrice AND p.unitPrice < :maxUnitPrice";
	
	public static final String findLikeProductName = "SELECT p FROM Product p WHERE p.name LIKE : productName";
	
	public static final String findInCategoryName = "SELECT p FROM Product p LEFT JOIN p.category c WHERE c.categoryName IN(:categoryName1 , :categoryName2)";
	
	public static final String findAllProduct = "SELECT p FROM Product p WHERE p.unitPrice > ALL(SELECT p2.uitPrice FROM Product p2 WHERE p2.category.categoryId";
	
	public static final String findFunctionPrice  = "SELECT AVG(p.unitPrice),SUM(p.unitPrice), MAX(p.unitPrice), MIN(p.unitPrice),COUNT(p) FROM Product p";
	
	public static final String findGroupByCategory = "SELECT p.category.name , AVG(p.unitPrice) FROM Product p GROUP BY p.category.name";
	
	public static final String findGroupByHavingCategory = "SELECT p.category.name , AVG(p.unitPrice) FROM Product p GROUP BY p.category.name HAVING";
	
	public static final String findOderderByPrice ="SELCET p FROM Product p ORDER BY p.unitPrice DESC";
}
